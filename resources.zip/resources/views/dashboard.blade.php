@extends('layouts.app')

@section('content')
<div class="container py-4">
    <h2 class="text-2xl font-bold mb-4">پنل کاربری {{ auth()->user()->first_name }}</h2>

    <!-- Nav tabs -->
    <ul class="nav nav-tabs" id="dashboardTabs" role="tablist">
        @foreach ([
            'profile' => 'تکمیل مشخصات فردی',
            'programs' => 'برنامه‌های من',
            'courses' => 'دوره‌های من',
            'reports' => 'گزارش‌های من',
            'payments' => 'پرداخت‌ها',
            'tickets' => 'تیکت‌ها',
        ] as $id => $label)
            <li class="nav-item" role="presentation">
                <button class="nav-link @if ($loop->first) active @endif" id="{{ $id }}-tab"
                        data-bs-toggle="tab" data-bs-target="#{{ $id }}" type="button" role="tab">
                    {{ $label }}
                </button>
            </li>
        @endforeach
    </ul>

    <!-- Tab panes -->
    <div class="tab-content mt-4" id="dashboardTabsContent">

        <div class="tab-pane fade show active" id="profile" role="tabpanel">
            @include('dashboard.partials.profile-form')
        </div>

        <div class="tab-pane fade" id="programs" role="tabpanel">
            @include('dashboard.tabs.my-programs')
        </div>

        <div class="tab-pane fade" id="courses" role="tabpanel">
            @include('dashboard.tabs.my-courses', ['courses' => $courses])
        </div>

        <div class="tab-pane fade" id="reports" role="tabpanel">
            @include('dashboard.tabs.reports', [
                'users' => $users,
                'reports' => $reports
            ])
        </div>

        <div class="tab-pane fade" id="payments" role="tabpanel">
        @include('dashboard.tabs.payments', ['payments' => $payments])
        </div>

        <div class="tab-pane fade" id="tickets" role="tabpanel">
            @include('dashboard.tabs.tickets')
        </div>

    </div>
</div>
@endsection
